import React from 'react'
import Dashboard from './Dashbord'

const CardView = () => {
  return (
    <Dashboard />
  )
}

export default CardView