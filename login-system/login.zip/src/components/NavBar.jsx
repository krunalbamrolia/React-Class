// import React from 'react'

// const NavBar = () => {
//   return (
//     <div>NavBar</div>
//   )
// }

// export default NavBar



import React, { useState } from 'react';
import { Link } from "react-router-dom";
import CardAdd from './pages/CardAdd';

const NavBar = ({ onAddCard }) => {
  const [showPopup, setShowPopup] = useState(false);

  const openPopup = () => {
    setShowPopup(true);
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <Link to={'/'} className="navbar-brand">Navbar</Link>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div className="navbar-nav">
            <Link to={'/cardview'} className="nav-item nav-link">View</Link>
            <button className="nav-item nav-link btn btn-link" onClick={openPopup}>Add-Card</button>
          </div>
        </div>
      </nav>
      {showPopup && <CardAdd onAddCard={onAddCard} onClose={closePopup} />}
    </>
  );
}

export default NavBar;
