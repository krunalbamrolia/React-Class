import React from 'react'
  
  const Error = ({ message }) => {
    return (
        <h6 style={{ color: 'red' }}>{message}</h6>
    )
  }
  
  export default Error